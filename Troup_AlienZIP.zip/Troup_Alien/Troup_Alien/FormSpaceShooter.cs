﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Troup_Alien
{
    public partial class FormSpaceShooter : Form
    {
        Random gen = new Random();

        public FormSpaceShooter()
        {
            InitializeComponent();
        }

        private void SpaceShooterForm_KeyDown(object sender, KeyEventArgs e)

        {
            if (e.KeyCode == Keys.W)

            {

                pictureBoxship.Location = new Point(pictureBoxship.Location.X, pictureBoxship.Location.Y - 2);

            }

            else if (e.KeyCode == Keys.S)

            {

                pictureBoxship.Location = new Point(pictureBoxship.Location.X, pictureBoxship.Location.Y + 2);
            }

            {
                if (e.KeyCode == Keys.Space)
                    pictureBoxfireball.Location = new Point(pictureBoxship.Location.X, pictureBoxship.Location.Y + 10);
                  
            }
        } 
                    
                    
            



        private void FormSpaceShooter_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            tmrSpaceshooter.Start();
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            tmrSpaceshooter.Stop();
        }

        private void tmr_refresher(object sender, EventArgs e)
        {
            
            int amtMoveInXAlien1 = gen.Next(10); //This variable will be used to determine how many pixels we will move to the left
            int amtMoveInYAlien1 = gen.Next(-5, 6); //This variable will be used to determine if we should move up or down on the Y axis
            //Move the alien the amount specified above by specifying a new location
            pictureBoxalien1.Location = new Point(pictureBoxalien1.Location.X - amtMoveInXAlien1, pictureBoxalien1.Location.Y + amtMoveInYAlien1);


            if (pictureBoxalien1.Location.X < 300) //if the picAlien1's X location is less than 300
                                                   //If it is, move the picAlien1 (your first alien) to a new Point with x Location at 1200
                                                   //and y position at a random integer between 100 and 400.

            { pictureBoxalien1.Location = new Point(1200, gen.Next(100, 400)); }


            int amtMoveInXAlien2 = gen.Next(10); //This variable will be used to determine how many pixels we will move to the left
            int amtMoveInYAlien2 = gen.Next(-5, 6); //This variable will be used to determine if we should move up or down on the Y axis
            //Move the alien the amount specified above by specifying a new location
            pictureBoxalien2.Location = new Point(pictureBoxalien2.Location.X - amtMoveInXAlien2, pictureBoxalien2.Location.Y + amtMoveInYAlien2);


            if (pictureBoxalien2.Location.X < 300) //if the picAlien2's X location is less than 300
                                                   //If it is, move the picAlien2 (2nd alien) to a new Point with x Location at 1200
                                                   //and y position at a random integer between 100 and 400.

            { pictureBoxalien2.Location = new Point(1200, gen.Next(100, 400)); }

            int amtMoveInXAlien3 = gen.Next(10); //This variable will be used to determine how many pixels we will move to the left
            int amtMoveInYAlien3 = gen.Next(-5, 6); //This variable will be used to determine if we should move up or down on the Y axis
            //Move the alien the amount specified above by specifying a new location
            pictureBoxalien3.Location = new Point(pictureBoxalien3.Location.X - amtMoveInXAlien3, pictureBoxalien3.Location.Y + amtMoveInYAlien3);


            if (pictureBoxalien3.Location.X < 300) //if the picAlien3's X location is less than 300
                                                   //If it is, move the picAlien3 (3rd alien) to a new Point with x Location at 1200
                                                   //and y position at a random integer between 100 and 400.

            { pictureBoxalien3.Location = new Point(1200, gen.Next(100, 400)); }
            // pictureBoxfireball visible then move the bullet by setting a new location and adding 5 to the x position as shown below.  Keep the Y position the same.
            if (pictureBoxfireball.Visible = true)
                pictureBoxfireball.Location = new Point(pictureBoxfireball.Location.X + 5, pictureBoxfireball.Location.Y);

            // Make bullet invisible off screen
            if (pictureBoxfireball.Location.X > this.Width)
            {
                pictureBoxfireball.Visible = false;
            }
            // Collision with fireball and alien 1
            if (pictureBoxalien1.Visible == true && pictureBoxfireball.Bounds.IntersectsWith(pictureBoxalien1.Bounds))
            {
                pictureBoxalien1.Visible = false;
                pictureBoxfireball.Visible = false;
            }
            // Collision with fireball and alien 2
            if (pictureBoxalien2.Visible == true && pictureBoxfireball.Bounds.IntersectsWith(pictureBoxalien2.Bounds))
            {
                pictureBoxalien2.Visible = false;
                pictureBoxfireball.Visible = false;
            }
            // Collision with fireball and alien 3
            if (pictureBoxalien3.Visible == true && pictureBoxfireball.Bounds.IntersectsWith(pictureBoxalien3.Bounds))
            {
                pictureBoxalien3.Visible = false;
                pictureBoxfireball.Visible = false;
            } 

            
            




        }








    }

}
    

