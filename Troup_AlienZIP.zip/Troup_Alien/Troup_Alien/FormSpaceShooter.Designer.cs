﻿namespace Troup_Alien
{
    partial class FormSpaceShooter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrSpaceshooter = new System.Windows.Forms.Timer(this.components);
            this.panelspace = new System.Windows.Forms.Panel();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.pictureBoxalien3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxalien2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxalien1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxfireball = new System.Windows.Forms.PictureBox();
            this.pictureBoxship = new System.Windows.Forms.PictureBox();
            this.panelspace.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfireball)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxship)).BeginInit();
            this.SuspendLayout();
            // 
            // tmrSpaceshooter
            // 
            this.tmrSpaceshooter.Tick += new System.EventHandler(this.tmr_refresher);
            // 
            // panelspace
            // 
            this.panelspace.BackColor = System.Drawing.Color.Gainsboro;
            this.panelspace.Controls.Add(this.buttonStop);
            this.panelspace.Controls.Add(this.buttonStart);
            this.panelspace.Location = new System.Drawing.Point(1, 0);
            this.panelspace.Name = "panelspace";
            this.panelspace.Size = new System.Drawing.Size(200, 366);
            this.panelspace.TabIndex = 0;
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(11, 72);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(11, 12);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // pictureBoxalien3
            // 
            this.pictureBoxalien3.Image = global::Troup_Alien.Properties.Resources.alien3;
            this.pictureBoxalien3.Location = new System.Drawing.Point(735, 255);
            this.pictureBoxalien3.Name = "pictureBoxalien3";
            this.pictureBoxalien3.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxalien3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxalien3.TabIndex = 6;
            this.pictureBoxalien3.TabStop = false;
            // 
            // pictureBoxalien2
            // 
            this.pictureBoxalien2.Image = global::Troup_Alien.Properties.Resources.alien2;
            this.pictureBoxalien2.Location = new System.Drawing.Point(735, 189);
            this.pictureBoxalien2.Name = "pictureBoxalien2";
            this.pictureBoxalien2.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxalien2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxalien2.TabIndex = 5;
            this.pictureBoxalien2.TabStop = false;
            // 
            // pictureBoxalien1
            // 
            this.pictureBoxalien1.Image = global::Troup_Alien.Properties.Resources.alien1;
            this.pictureBoxalien1.Location = new System.Drawing.Point(735, 121);
            this.pictureBoxalien1.Name = "pictureBoxalien1";
            this.pictureBoxalien1.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxalien1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxalien1.TabIndex = 4;
            this.pictureBoxalien1.TabStop = false;
            // 
            // pictureBoxfireball
            // 
            this.pictureBoxfireball.Image = global::Troup_Alien.Properties.Resources.fireball;
            this.pictureBoxfireball.Location = new System.Drawing.Point(313, 176);
            this.pictureBoxfireball.Name = "pictureBoxfireball";
            this.pictureBoxfireball.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxfireball.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxfireball.TabIndex = 3;
            this.pictureBoxfireball.TabStop = false;
            // 
            // pictureBoxship
            // 
            this.pictureBoxship.Image = global::Troup_Alien.Properties.Resources.spaceship2;
            this.pictureBoxship.Location = new System.Drawing.Point(207, 162);
            this.pictureBoxship.Name = "pictureBoxship";
            this.pictureBoxship.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxship.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxship.TabIndex = 2;
            this.pictureBoxship.TabStop = false;
            // 
            // FormSpaceShooter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(857, 365);
            this.Controls.Add(this.pictureBoxalien3);
            this.Controls.Add(this.pictureBoxalien2);
            this.Controls.Add(this.pictureBoxalien1);
            this.Controls.Add(this.pictureBoxfireball);
            this.Controls.Add(this.pictureBoxship);
            this.Controls.Add(this.panelspace);
            this.Name = "FormSpaceShooter";
            this.Text = "Space Shooter";
            this.Load += new System.EventHandler(this.FormSpaceShooter_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SpaceShooterForm_KeyDown);
            this.panelspace.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxalien1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxfireball)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxship)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrSpaceshooter;
        private System.Windows.Forms.Panel panelspace;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.PictureBox pictureBoxship;
        private System.Windows.Forms.PictureBox pictureBoxfireball;
        private System.Windows.Forms.PictureBox pictureBoxalien1;
        private System.Windows.Forms.PictureBox pictureBoxalien2;
        private System.Windows.Forms.PictureBox pictureBoxalien3;
    }
}

